/* Dependencies */

const areObjects = require('are-objects');
const areArrays = require('are-arrays');



const sum = (a, b) => a + b
exports.sum = sum